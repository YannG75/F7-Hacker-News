<template>
  <f7-page>
    <f7-navbar>
      <div class="navbar">
        <div class="navbar-bg"></div>
        <div class="navbar-inner sliding" style="background: #ff9e33;">
          <div class="left">
            <a class="link back" style="color: black;">
              <i class="icon icon-back"></i>
              <span>Not found</span>
            </a>
          </div>
        </div>
      </div>
    </f7-navbar>
    <f7-block strong>
      <p>Sorry</p>
      <p>Requested content not found.</p>
    </f7-block>
  </f7-page>
</template>
<script>
  export default {};
</script>